package org.simplilearn.dao;

import java.util.List;

import org.simplilearn.entities.Emp;

public interface EmpDao {
	void insert(Emp e);
	void delete(int eno);
	Emp get(int eno);
	List<Emp> getAll();
	void update(int eno,Emp e);
}
