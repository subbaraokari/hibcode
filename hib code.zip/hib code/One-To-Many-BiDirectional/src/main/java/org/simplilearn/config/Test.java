package org.simplilearn.config;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.entities.Flight;
import org.simplilearn.entities.Passenger;

public class Test {

	public static void main(String[] args) {
		//insertFlight();
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Flight flight=session.get(Flight.class, 1);
		
	}

	private static void insertFlight() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Passenger passenger1=new Passenger();
			passenger1.setName("raj");
			passenger1.setAddress("Chennai");
			Passenger passenger2=new Passenger();
			passenger2.setName("Ram");
			passenger2.setAddress("Hyd");
			Flight flight=new Flight();
			flight.setName("Indigo");
			flight.setCapacity(30);
			//flight.getPassengers().add(passenger1);
			//flight.getPassengers().add(passenger2);
			flight.addPassenger(passenger1);
			flight.addPassenger(passenger2);
			passenger1.setFlight(flight);
			passenger2.setFlight(flight);
			session.save(flight);

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

}
