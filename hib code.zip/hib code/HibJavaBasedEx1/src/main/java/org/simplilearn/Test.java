package org.simplilearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Emp;

public class Test {

	public static void main(String[] args) {
		//insertData();
		getData();
	}

	private static void getData() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Emp e=session.load(Emp.class, 1);
		System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
	}

	private static void insertData() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(new Emp("ram","Hyd"));
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

}
