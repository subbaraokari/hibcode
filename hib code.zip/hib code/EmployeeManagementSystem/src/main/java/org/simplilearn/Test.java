package org.simplilearn;

import java.util.List;

import org.simplilearn.dao.EmpDao;
import org.simplilearn.dao.EmpDaoImpl;
import org.simplilearn.entities.Emp;

public class Test {

	public static void main(String[] args) {
		EmpDao dao=new EmpDaoImpl();
		//dao.insert(new Emp("rakesh", "Hyd"));
		List<Emp> employees=dao.getAll();
		System.out.println("The employee details are");
		for(Emp e:employees)
		{
			System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
		}
	}

}
