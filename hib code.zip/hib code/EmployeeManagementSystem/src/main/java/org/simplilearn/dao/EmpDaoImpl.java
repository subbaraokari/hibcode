package org.simplilearn.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Emp;

public class EmpDaoImpl implements EmpDao{

	@Override
	public void insert(Emp e) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(e);
			tx.commit();
		} catch (Exception e2) {
			tx.rollback();
			e2.printStackTrace();
		}
		session.close();
	}

	@Override
	public void delete(int eno) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Emp e=session.get(Emp.class, eno);
			session.delete(e);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

	@Override
	public List<Emp> getAll() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Query<Emp> query=session.createQuery("select e from org.simplilearn.entities.Emp e");
		return query.list();
	}

	@Override
	public Emp get(int eno) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		return session.get(Emp.class, eno);
	}

	@Override
	public void update(int eno, Emp e) {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Emp e1=session.get(Emp.class, eno);
			e1.setName(e.getName());
			e1.setAddress(e.getAddress());
			session.save(e1);
			tx.commit();
		} catch (Exception e2) {
			tx.rollback();
			e2.printStackTrace();
		}
	}
	
}
