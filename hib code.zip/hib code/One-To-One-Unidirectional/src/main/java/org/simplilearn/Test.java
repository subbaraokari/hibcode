package org.simplilearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.simplilearn.config.HibConfig;
import org.simplilearn.entities.Passport;
import org.simplilearn.entities.Person;

public class Test {

	public static void main(String[] args) {
		//insertData();
		
		getData();
	}

	private static void getData() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Passport passport=session.get(Passport.class, 1);
		Person person=passport.getPerson();
		System.out.println(passport.getPassId()+"\t"+passport.getPassNo());
		System.out.println(person.getPid()+"\t"+person.getName()+"\t"+person.getAddress());
	}

	private static void insertData() {
		SessionFactory factory=HibConfig.getSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Passport passport=new Passport("322324343", "sddsajd");
			Person person=new Person();
			person.setName("Suresh");
			person.setAddress("Chennai");
			person.setPassport(passport);
			session.save(person);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

}
