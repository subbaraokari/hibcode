package org.simplilearn;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.simplilearn.entites.Emp;

public class Test {

	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate.cfg.xml");
		//insertEmployee(configuration);
		//deleteEmployee(configuration);
		//getting single employee
		getEmployee(configuration);
		
	}

	private static void getEmployee(Configuration configuration) {
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Emp e=session.load(Emp.class, 1); //proxy design pattern
		
		System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
	}

	private static void deleteEmployee(Configuration configuration) {
		SessionFactory factory=configuration.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			Emp e=session.get(Emp.class, 3);
			session.delete(e);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

	private static void insertEmployee(Configuration configuration) {
		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(new Emp("Vamsi", "Chennai"));
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}

}
